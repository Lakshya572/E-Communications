import React from 'react';
import { Outlet, NavLink } from 'react-router-dom';
import Setting from "../assets/Settings.png"
import About from "../assets/About.png"
import Cart from "../assets/Cart.png"
import Login from "../assets/Login.png"
import Home from "../assets/Home.png"

const Layout = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <NavLink to="/" className="text-2xl font-bold text-indigo-600">
                E-Communication
              </NavLink>
            </div>
            <nav className="flex space-x-8 items-center">
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  `group flex items-center space-x-2 text-gray-700 hover:text-indigo-600 transition-all duration-300 transform hover:scale-110 ${
                    isActive ? 'text-indigo-600 font-semibold' : ''
                  }`
                }
              >
                <img src={Home} alt="Home" className="w-6 h-6 transition-transform duration-300 group-hover:rotate-12"/>
                <span className="hidden sm:inline">Home</span>
              </NavLink>
              <NavLink
                to="/login"
                className={({ isActive }) =>
                  `group flex items-center space-x-2 text-gray-700 hover:text-indigo-600 transition-all duration-300 transform hover:scale-110 ${
                    isActive ? 'text-indigo-600 font-semibold' : ''
                  }`
                }
              >
                <img src={Login} alt="Login" className="w-6 h-6 transition-transform duration-300 group-hover:rotate-12"/>
                <span className="hidden sm:inline">Login</span>
              </NavLink>
              <NavLink
                to="/cart"
                className={({ isActive }) =>
                  `group flex items-center space-x-2 text-gray-700 hover:text-indigo-600 transition-all duration-300 transform hover:scale-110 ${
                    isActive ? 'text-indigo-600 font-semibold' : ''
                  }`
                }
              >
                <img src={Cart} alt="Cart" className="w-6 h-6 transition-transform duration-300 group-hover:rotate-12"/>
                <span className="hidden sm:inline">Cart</span>
              </NavLink>
              <NavLink
                to="/about"
                className={({ isActive }) =>
                  `group flex items-center space-x-2 text-gray-700 hover:text-indigo-600 transition-all duration-300 transform hover:scale-110 ${
                    isActive ? 'text-indigo-600 font-semibold' : ''
                  }`
                }
              >
                <img src={About} alt="About" className="w-6 h-6 transition-transform duration-300 group-hover:rotate-12"/>
                <span className="hidden sm:inline">About</span>
              </NavLink>
              <NavLink
                to="/settings"
                className={({ isActive }) =>
                  `group flex items-center space-x-2 text-gray-700 hover:text-indigo-600 transition-all duration-300 transform hover:scale-110 ${
                    isActive ? 'text-indigo-600 font-semibold' : ''
                  }`
                }
              >
                <img src={Setting} alt="Settings" className="w-6 h-6 transition-transform duration-300 group-hover:rotate-12"/>
                <span className="hidden sm:inline">Settings</span>
              </NavLink>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p>&copy; 2024 E-Communication. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
