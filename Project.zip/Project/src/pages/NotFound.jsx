import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import "../pages/NotFoud.css"

const NotFound = () => {
  const [countdown, setCountdown] = useState(5);
  const navigate = useNavigate();

  useEffect(() => {
    // Countdown timer
    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    // Redirect when countdown reaches 0
    if (countdown === 0) {
      navigate('/');
    }

    return () => clearInterval(timer);
  }, [countdown, navigate]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      {/* Illustration */}
      <img
        src="https://undraw.co/api/illustrations/404-error.svg"
        alt="Page Not Found"
        className="w-full max-w-md mb-6 animate-bounce-slow"
      />

      {/* Text */}
      <h1 className="text-6xl font-bold text-indigo-600 mb-4">404</h1>
      <h2 className="text-2xl font-semibold text-gray-800 mb-2">
        Page Not Found
      </h2>
      <p className="text-gray-600 mb-6 max-w-md">
        Oops! The page you're looking for doesn’t exist or has been moved.
        Redirecting you to the homepage in{" "}
        <span className="font-bold text-indigo-600">{countdown}</span> seconds.
      </p>

      {/* Back Home Button */}
      <Link
        to="/"
        className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        Go Back Home Now
      </Link>
    </div>
  );
};

export default NotFound;
