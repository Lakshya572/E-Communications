import React from 'react';
import { Link } from 'react-router-dom';
import { products } from '../data/products';
import ProductList from '../components/ProductList';

const Home = () => {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg p-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Welcome to E-Communication
          </h1>
          <p className="text-xl mb-8">
            Your one-stop destination for all communication needs
          </p>
          <Link
            to="/cart"
            className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Shop Now
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="grid md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-indigo-600 text-3xl mb-4">📱</div>
          <h3 className="text-xl font-semibold mb-2">Latest Devices</h3>
          <p className="text-gray-600">
            Discover the newest smartphones, tablets, and accessories
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-indigo-600 text-3xl mb-4">🚀</div>
          <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
          <p className="text-gray-600">
            Get your products delivered to your doorstep quickly
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-indigo-600 text-3xl mb-4">💰</div>
          <h3 className="text-xl font-semibold mb-2">Best Prices</h3>
          <p className="text-gray-600">
            Competitive pricing on all communication products
          </p>
        </div>
      </section>

      {/* Products Section */}
      <section>
        <h2 className="text-3xl font-bold text-gray-900 mb-6">All Products</h2>
        <ProductList products={products} />
      </section>
    </div>
  );
};

export default Home;
